package com.cg.service;

import com.cg.dao.DaoImpl;
import com.cg.dao.IDao;
import com.cg.entity.AuthorDetails;

public class AuthorService implements IAuthorService{
   IDao dao=null;
	@Override
	public void addauthor(AuthorDetails author) {
		dao=new DaoImpl();
		dao.beginTransaction();
		dao.addauthor(author);
		dao.commitTransaction();
		
	}
	@Override
	public void updateauthor(AuthorDetails author) {
		dao=new DaoImpl();
		dao.beginTransaction();
		dao.updateauthor(author);
		dao.commitTransaction();
		
	}
	@Override
	public void removeauthor(AuthorDetails author) {
		dao=new DaoImpl();
		dao.beginTransaction();
		dao.removeauthor(author);
		dao.commitTransaction();
		
	}
	@Override
	public AuthorDetails findauthor(int authorId) {
		dao=new DaoImpl();
		return dao.findauthor(authorId);
		
	}

	

}

package com.cg.service;

import com.cg.entity.AuthorDetails;

public interface IAuthorService {
	public abstract void addauthor(AuthorDetails author);
	public abstract void updateauthor(AuthorDetails author);
	public abstract void removeauthor(AuthorDetails author);
	public abstract AuthorDetails findauthor(int authorId);

}

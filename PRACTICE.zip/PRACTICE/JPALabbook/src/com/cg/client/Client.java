package com.cg.client;

import com.cg.entity.AuthorDetails;
import com.cg.service.AuthorService;
import com.cg.service.IAuthorService;

public class Client {
	public static void main(String[] args) {
		AuthorDetails t=new AuthorDetails();
		IAuthorService ser=new AuthorService();
		t.setAuthorId(100);
		t.setFirstName("soumya");
		t.setMiddleName("reddy");
		t.setLastName("somu");
		t.setMobileno("123456");
		ser.addauthor(t);
		System.out.println("id:"+t.getAuthorId());
		System.out.println("firstname:"+t.getFirstName());
		System.out.println("middlename"+t.getMiddleName());
		System.out.println("lastname:"+t.getLastName());
		System.out.println("mobileno:"+t.getMobileno());
		t=ser.findauthor(100);
		 t.setFirstName("sai");
		 t.setLastName("aswathy");
		 t.setMiddleName("ss");
		 ser.updateauthor(t);
		 System.out.println("after updating");
		 System.out.println("id:"+t.getAuthorId());
			System.out.println("firstname:"+t.getFirstName());
			System.out.println("middlename:"+t.getMiddleName());
			System.out.println("lastname:"+t.getLastName());
			System.out.println("mobileno:"+t.getMobileno());
		 
	}

}

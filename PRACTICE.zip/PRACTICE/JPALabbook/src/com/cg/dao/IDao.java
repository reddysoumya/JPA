package com.cg.dao;

import com.cg.entity.AuthorDetails;

public interface IDao {
	public abstract void addauthor(AuthorDetails author);	
	public abstract void beginTransaction();
	public abstract void commitTransaction();
	public abstract void updateauthor(AuthorDetails author);
	public abstract void removeauthor(AuthorDetails author);
	public abstract AuthorDetails findauthor(int authorId);

}

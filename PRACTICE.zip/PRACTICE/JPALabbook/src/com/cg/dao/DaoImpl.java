package com.cg.dao;

import javax.persistence.EntityManager;

import com.cg.entity.AuthorDetails;

public class DaoImpl implements IDao {
	private EntityManager entitymanager;

	public DaoImpl() {
		entitymanager=JPAUtil.getEntityManager();
	}


	@Override
	public void addauthor(AuthorDetails author) {
		entitymanager.persist(author);
		
	}

	@Override
	public void beginTransaction() {
		entitymanager.getTransaction().begin();
		
	}

	@Override
	public void commitTransaction() {
		entitymanager.getTransaction().commit();
		
	}

	@Override
	public void updateauthor(AuthorDetails author) {
		entitymanager.merge(author);
		
	}

	@Override
	public void removeauthor(AuthorDetails author) {
		entitymanager.remove(author);
		
	}

	@Override
	public AuthorDetails findauthor(int authorId) {
		AuthorDetails t=entitymanager.find(AuthorDetails.class,authorId);
		return t;
	}

}

package com.cg.springdemo4;

public interface IExchangeService {
	public double getExchangeRate();

}

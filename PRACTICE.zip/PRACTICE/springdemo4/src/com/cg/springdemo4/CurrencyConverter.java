package com.cg.springdemo4;

public interface CurrencyConverter {
public abstract double dollorToRupee(double dollars);
}

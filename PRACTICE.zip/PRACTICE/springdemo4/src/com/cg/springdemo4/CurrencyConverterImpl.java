package com.cg.springdemo4;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("currencyConverter")
public class CurrencyConverterImpl implements CurrencyConverter{
	
	public CurrencyConverterImpl() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Autowired
	private IExchangeService exchangeservice;
	@Override
	public double dollorToRupee(double dollars) {
		
		return dollars*exchangeservice.getExchangeRate();
	}
	public IExchangeService getExchangeservice() {
		return exchangeservice;
	}
	public void setExchangeservice(IExchangeService exchangeservice) {
		this.exchangeservice = exchangeservice;
	}
	@PostConstruct
	public void init()
	{
		System.out.println("in init");
	}
	@PreDestroy
	public void destroy()
	{
		System.out.println("in destroy method");
	}
	@Autowired
	public CurrencyConverterImpl(IExchangeService exchangeservice) {
		super();
		this.exchangeservice = exchangeservice;
	}
	
	

}

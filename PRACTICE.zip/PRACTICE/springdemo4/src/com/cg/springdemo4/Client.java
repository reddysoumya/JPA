package com.cg.springdemo4;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Client {

	public static void main(String[] args) {
		/*Resource res=new ClassPathResource("currencyconverter.xml");
		BeanFactory factory=new XmlBeanFactory(res);
		CurrencyConverter con=(CurrencyConverter)factory.getBean("currencyConverter");*/
		
			ApplicationContext ctx= new ClassPathXmlApplicationContext("currencyconverter.xml");
				CurrencyConverterImpl curr= (CurrencyConverterImpl) ctx.getBean("currencyConverter");
				
				System.out.println(curr.dollorToRupee(50.0)); 

	}

}

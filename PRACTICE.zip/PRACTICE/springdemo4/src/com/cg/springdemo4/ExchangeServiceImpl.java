package com.cg.springdemo4;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("exchangeService")
public class ExchangeServiceImpl implements IExchangeService{
	@Value("90.00")
	private double exchangerate;

	@Override
	public double getExchangeRate() {
		// TODO Auto-generated method stub
		return exchangerate;
	}

	public double getExchangerate() {
		return exchangerate;
	}
//parameter
	public ExchangeServiceImpl(double exchangerate) {
		super();
		this.exchangerate = exchangerate;
	}
//default
	public ExchangeServiceImpl() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	
	

}

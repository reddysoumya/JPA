package com.cg.jpa;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class studentMain {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("form");
		EntityManager em=emf.createEntityManager();
		em.getTransaction().begin();
		Student student=new Student();
		student.setStudentName("soumyasomu");
		em.persist(student);
		em.getTransaction().commit();
		em.close();
		emf.close();

	}

}

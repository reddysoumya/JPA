package com.cg.springdemo;

public interface CurrencyConverter {
public abstract double dollorToRupee(double dollars);
}

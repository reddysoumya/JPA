package com.cg.springdemo;

public interface IExchangeService {
	public double getExchangeRate();

}

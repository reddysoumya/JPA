package com.cg.springdemo;

public class ExchangeServiceImpl implements IExchangeService{
	private double exchangerate;

	public double getExchangerate() {
		return exchangerate;
	}

	public void setExchangerate(double exchangerate) {
		this.exchangerate = exchangerate;
	}

	@Override
	public double getExchangeRate() {
		// TODO Auto-generated method stub
		return exchangerate;
	}

	public ExchangeServiceImpl(double exchangerate) {
		super();
		this.exchangerate = exchangerate;
	}
	

}

package com.cg.springdemo;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Client {

	public static void main(String[] args) {
		Resource res=new ClassPathResource("currencyconverter.xml");
		BeanFactory factory=new XmlBeanFactory(res);
		CurrencyConverter con=(CurrencyConverter)factory.getBean("currencyconverter");
		double rupees=con.dollorToRupee(100.0);
		System.out.println(rupees);

	}

}

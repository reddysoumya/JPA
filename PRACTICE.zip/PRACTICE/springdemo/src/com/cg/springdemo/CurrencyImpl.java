package com.cg.springdemo;

public class CurrencyImpl implements CurrencyConverter{
	private IExchangeService exchangeservice;
	@Override
	public double dollorToRupee(double dollars) {
		
		return dollars*exchangeservice.getExchangeRate();
	}
	public IExchangeService getExchangeservice() {
		return exchangeservice;
	}
	public void setExchangeservice(IExchangeService exchangeservice) {
		this.exchangeservice = exchangeservice;
	}
	
	

}

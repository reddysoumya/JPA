package com.cg.client;

import com.cg.entity.Book;
import com.cg.service.BookService;
import com.cg.service.IBookService;

public class Client {
	public static void main(String[] args) {
		//Book b=new Book();
		IBookService i=new BookService();
		System.out.println("listing total no f books");
		System.out.println("total books:"+i.getBookCount());
		System.out.println("---------------------------");
		System.out.println("listing book by id");
		System.out.println("book with id 105"+i.getBookById(105));
		System.out.println("-----------------------------------");
		System.out.println("listing all books");
		for(Book b:i.getAllBooks())
		{
		System.out.println("books"+b);
		}
		System.out.println("-------------------------------");
		System.out.println("listing book on android");
		for(Book b:i.getBookBytitle("Android"))
		{
			System.out.println(b);
		}
		System.out.println("--------------------------------");
		System.out.println("listing between pricerange");
		for(Book b:i.getAllBooksinRange(300, 600))
		{
			System.out.println(b);
		}
		System.out.println("-------------------");
		System.out.println("listing janson books");
		for(Book b:i.getAuthorBooks("Janson"))
		{
			System.out.println(b);
		}
		
	}

}

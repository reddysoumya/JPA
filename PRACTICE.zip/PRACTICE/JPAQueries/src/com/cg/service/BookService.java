package com.cg.service;

import java.util.List;

import com.cg.dao.DaoImpl;
import com.cg.dao.IDaoImpl;
import com.cg.entity.Book;

public class BookService implements IBookService{
static IDaoImpl id1=null;
	@Override
	public Book getBookById(int id) {
		id1=new DaoImpl();
		return id1.getBookById(id);
	}

	@Override
	public List<Book> getBookBytitle(String title) {
		id1=new DaoImpl();
		
		return id1.getBookBytitle(title);
	}

	@Override
	public long getBookCount() {
		id1=new DaoImpl();
		
		return id1.getBookCount();
	}

	@Override
	public List<Book> getAuthorBooks(String author) {
		id1=new DaoImpl();
		return id1.getAuthorBooks(author);
	}

	@Override
	public List<Book> getAllBooks() {
		id1=new DaoImpl();
		return id1.getAllBooks();
	}

	@Override
	public List<Book> getAllBooksinRange(double low, double high) {
		id1=new DaoImpl();
		
		return id1.getAllBooksinRange(low, high);
	}

	@Override
	public String getbookbyid(int id) {
		id1=new DaoImpl();
		return null;
	}

}

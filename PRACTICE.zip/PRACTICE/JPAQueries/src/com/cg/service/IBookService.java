package com.cg.service;

import java.util.List;

import com.cg.entity.Book;

public interface IBookService {
	public abstract Book getBookById(int id);
	public abstract List<Book> getBookBytitle(String title);
	public abstract long getBookCount();
	public abstract List<Book> getAuthorBooks(String author);
	public abstract List<Book> getAllBooks();
	public abstract List<Book> getAllBooksinRange(double low,double high);
	public abstract String getbookbyid(int id);
	

}

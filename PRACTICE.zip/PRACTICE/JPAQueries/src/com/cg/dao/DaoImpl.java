package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.entity.Book;

public class DaoImpl implements IDaoImpl{
	private EntityManager entitymanager;
	public DaoImpl() {
		entitymanager=JPAUtil.getEntityManager();
	}

	@Override
	public Book getBookById(int id) {
		Book b=entitymanager.find(Book.class, id);
		return b;
	}

	@Override
	public List<Book> getBookBytitle(String title) {
		String str="SELECT b FROM Book b WHERE b.title LIKE :ptitle";
		TypedQuery<Book> query=entitymanager.createQuery(str,Book.class);
		query.setParameter("ptitle","%"+title+"%");		
		return query.getResultList();
	}

	@Override
	public long getBookCount() {
		String str="select count(b.id) from Book b ";
		TypedQuery<Long> query=entitymanager.createQuery(str,Long.class);	
		Long count=query.getSingleResult();
		return count;
	}

	@Override
	public List<Book> getAuthorBooks(String author) {
		String str="SELECT b FROM Book b WHERE b.author LIKE :pauthor";
		TypedQuery<Book> query=entitymanager.createQuery(str,Book.class);
		query.setParameter("pauthor","%"+author+"%");		
		return query.getResultList();

	}

	@Override
	public List<Book> getAllBooks() {
		Query query=entitymanager.createNamedQuery("getallbooks");
		List<Book> list=query.getResultList();
		return list;
	}

	@Override
	public List<Book> getAllBooksinRange(double low, double high) {
	String str="SELECT b FROM Book b WHERE b.price BETWEEN :plow AND :phigh ";
	Query query=entitymanager.createQuery(str,Book.class);
	//query.setParameter("plow","%"+low+"%");
	//query.setParameter("phigh","%"+high+"%");
	query. setParameter("plow", low);
    query.setParameter("phigh",high);
	List<Book> list=query.getResultList();
	return list;
	
	
		
	}

}

package com.cg.client;

import com.cg.entity.Trainee;
import com.cg.service.ITraineeService;
import com.cg.service.TraineeService;

public class Client {

	public static void main(String[] args) {
		Trainee t=new Trainee();
		ITraineeService obj=new TraineeService();
		t.setTraineeId(191);
	    t.setTraineeName("sunny");
	    t.setTraineeSalary(107);
	    obj.addStudent(t);
	 //t=obj.findStudent(191);
	 System.out.println("Id:"+t.getTraineeName());
	 System.out.println("salary:"+t.getTraineeSalary());
	 
	t=obj.findStudent(191);
	 t.setTraineeName("aswathy");
	 obj.updateStudent(t);
	
	 System.out.println("name:"+t.getTraineeName());
	 System.out.println("salary:"+t.getTraineeSalary());
	 System.out.println("Id:"+t.getTraineeId());
	 
	 
	// obj.removeStudent(t);
	 System.out.println("program ends");
	 
	
	 
	    

	}

}

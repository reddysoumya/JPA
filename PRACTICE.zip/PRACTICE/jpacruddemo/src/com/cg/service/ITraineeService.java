package com.cg.service;

import com.cg.entity.Trainee;

public interface ITraineeService {
	public abstract void addStudent(Trainee Student);
	public abstract void updateStudent(Trainee Student);
	public abstract void removeStudent(Trainee Student);
	public abstract Trainee findStudent(int id);
	
	
	

}

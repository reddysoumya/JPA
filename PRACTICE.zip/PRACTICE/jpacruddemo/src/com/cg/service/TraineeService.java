package com.cg.service;

import javax.persistence.EntityManager;

import com.cg.dao.DaoImpl;
import com.cg.dao.ITraineeDao;
import com.cg.entity.Trainee;

public class TraineeService implements ITraineeService {
	ITraineeDao dao = null;

	@Override
	public void addStudent(Trainee Student) {
		dao=new DaoImpl();
		dao.beginTransaction();
		dao.addStudent(Student);
		dao.commitTransaction();		
	}

	@Override
	public void updateStudent(Trainee Student) {
		dao=new DaoImpl();
		dao.beginTransaction();
		dao.updateStudent(Student);
		dao.commitTransaction();
		
	}

	@Override
	public void removeStudent(Trainee Student) {
		dao=new DaoImpl();
		dao.beginTransaction();
		dao.removeStudent(Student);
		dao.commitTransaction();
		
	}

	@Override
	public Trainee findStudent(int id) {
		dao=new DaoImpl();
		return dao.findStudent(id);
		
	}


	

	
	

}

package com.cg.dao;

import com.cg.entity.Trainee;


public interface ITraineeDao {
	public abstract void addStudent(Trainee Student);
	public abstract void updateStudent(Trainee Student);
	public abstract void removeStudent(Trainee Student);
	public abstract Trainee findStudent(int id);	
	public abstract void beginTransaction();
	public abstract void commitTransaction();
	
}

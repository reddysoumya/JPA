package com.cg.dao;

import javax.persistence.EntityManager;

import com.cg.entity.Trainee;

public class DaoImpl implements ITraineeDao{
	private EntityManager entitymanager;


	public DaoImpl() {
		entitymanager=JPAUtil.getEntityManager();
	}

	@Override
	public void addStudent(Trainee Student) {
		 entitymanager.persist(Student);
		
	}

	@Override
	public void updateStudent(Trainee Student) {
		 entitymanager.merge(Student);
		
	}

	@Override
	public void removeStudent(Trainee Student) {
		 entitymanager.remove(Student);
		
	}
	@Override
	public void beginTransaction() {
		entitymanager.getTransaction().begin();
		
	}

	@Override
	public void commitTransaction() {
		entitymanager.getTransaction().commit();
		
	}

	@Override
	public Trainee findStudent(int id) {
		Trainee t=entitymanager.find(Trainee.class,id);
		return t;
		
	}


}

package com.cg.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name="ss")
public class Departmenttable implements Serializable{

	private static final long serialVersionUID = 1L;
	@Id
	private int id;
	private String name;

	@OneToMany(mappedBy="department",cascade=CascadeType.ALL)
	private Set<Employeetable> employees = new HashSet<>();

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<Employeetable> getEmployees() {
		return employees;
	}

	public void setEmployees(Set<Employeetable> employees) {
		this.employees = employees;
	}	
	public void addEmployee(Employeetable employee) {
		employee.setDepartment(this);			
		this.getEmployees().add(employee);
	}


}

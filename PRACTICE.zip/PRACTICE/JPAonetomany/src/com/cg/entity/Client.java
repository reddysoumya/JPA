package com.cg.entity;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {

	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		
		Departmenttable department = new Departmenttable();
		department.setId(10);
		department.setName("Sales");
		Employeetable e1 = new Employeetable();
		e1.setId(1001);
		e1.setName("Priya Sharma");
		e1.setSalary(4500);
		
		Employeetable e2 = new Employeetable();
		e2.setId(1002);
		e2.setName("Dinesh Kumar");
		e2.setSalary(5500);
		
		department.addEmployee(e1);
		department.addEmployee(e2);
		em.persist(department);
		
		System.out.println("Added department along with two employees to database.");

	}

}
